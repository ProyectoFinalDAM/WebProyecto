# Programa-del-Proyecto
Programa sobre una apliación de gestión de películas desarrollado para el Proyecto Integrador de final del curso DAM-B
Elaborado por los Alumnos: Pablo Marín, Andreu Francés, Marcos Sanz y Martín Peidro
